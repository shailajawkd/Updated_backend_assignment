package com.Ticket.MovieService.model;

import java.util.List;

import com.Ticket.MovieService.Entity.Movie;



public class MoviesList {
	
	private List<Movie> movies;

	public List<Movie> getMovies() {
		return movies;
	}

	public void setMovies(List<Movie> movies) {
		this.movies = movies;
	}
	
	
	

}
