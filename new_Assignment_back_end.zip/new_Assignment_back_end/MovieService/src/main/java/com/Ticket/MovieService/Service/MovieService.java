package com.Ticket.MovieService.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.Ticket.MovieService.Entity.Movie;
import com.Ticket.MovieService.Repository.MovieRepository;
import com.Ticket.MovieService.model.MoviesList;

@Service
public class MovieService {
	@Autowired
	MovieRepository mrepo;
	
	public List<Movie> getAllMovies(){
		
		List<Movie> allmovies=new ArrayList<>();
		
		Iterable<Movie> movies=mrepo.findAll();
		movies.forEach(allmovies::add);
		MoviesList list=new MoviesList();
		list.setMovies(allmovies);
		 return allmovies;
		
	}
	
	
	public ResponseEntity<Movie> addMovie(Movie movie) {
		Iterable<Movie> allmovies=mrepo.findAll();
		try {
			for(Movie movie1:allmovies) {
				if(movie1.getMovieName().equalsIgnoreCase(movie.getMovieName())) {
					 return ResponseEntity.badRequest().build();
				}
			}
			Movie newmovie=mrepo.save(movie);
			
			return ResponseEntity.ok(newmovie);
			
		}catch(Exception e) {
			 return ResponseEntity.badRequest().build();
		}
		
	}
	
	public Iterable<Movie> deleteMovieByMovieName(String moviename){
		 mrepo.deleteByMovieName(moviename);
		 return mrepo.findAll();
		
		
	}
	
	public ResponseEntity<Movie> getbyid(int id) {
		
		Optional<Movie> movie=mrepo.findById(id);
		try {
		if(movie.isPresent()) {
			System.out.println("inside if");
			return ResponseEntity.ok(movie.get());
		}else {
			return ResponseEntity.badRequest().build();
		}
		}catch(Exception e) {
			 return ResponseEntity.badRequest().build();
		}
		
	}
	
	
	
	public Movie getByMovieName(String moviename) {
		
		return mrepo.findByMovieName(moviename);
	}
	
	public Movie updateMovie(Movie movie,int movieid) {
		Optional<Movie> movie1=mrepo.findById(movieid);
		Movie newmovie=new Movie();
		if(movie1.isPresent()) {
//			newmovie=movie1.get();
			newmovie.setMovieId(movie.getMovieId());
			newmovie.setMovieName(movie.getMovieName());
			newmovie.setRating(movie.getRating());
			newmovie.setReleaseDate(movie.getReleaseDate());
			
		}

		   return  mrepo.save(newmovie);
	}

}
