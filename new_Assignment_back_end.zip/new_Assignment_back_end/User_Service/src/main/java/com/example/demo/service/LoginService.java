package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.UserDTO;
import com.example.demo.dto.UserLogin;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;

@Service
public class LoginService {

	@Autowired
	UserRepository repo;

	@Autowired
	RoleRepository rolerepo;

	/*
	 * public List<User> getAllUser(){ List<User> users= new ArrayList<User>();
	 * repo.findAll().forEach(users::add);
	 * 
	 * return users; }
	 */

	public User createUser(User user) throws Exception {
		String tempusername = user.getUserName();
		User userobj = null;
		if (tempusername != null && !"".equals(tempusername)) {
			 userobj = repo.findByUserName(tempusername);
			if (userobj != null) {
				throw new Exception("user with " + tempusername + " is already exist");
			}

		}
		
		userobj = repo.save(user);

		/* System.out.println(user.getEmail()); */
		User useren = new User();
		Role roleen = new Role();
		useren.setEmail(user.getEmail());
		useren.setPassword(user.getPassword());
		useren.setPhoneNumber(user.getPhoneNumber());
		/* useren.setUserId(user.getUserId()); */
		useren.setUserName(user.getUserName());

		Role role2 = new Role();

		role2.setUserRole(user.getRole1().getUserRole());
		/* rolerepo.save(role2); */

		useren.setRole1(role2);
		/* System.out.println(useren.getRole1().getUserRole()); */

		/* useren.setRole1(user.getRole1().getUserRole()); */
		/* useren.getRole1().setUserRole(user.getRole1().getUserRole()); */
		/* System.out.println(user.getEmail()); */

		/* useren=user.createEntity(user); */
		/* useren.getUser_role1().setUserRole(userRole); */
		/* System.out.println(user.getRole1().getUserRole()); */
		/*
		 * System.out.println(user.getRole1().getUserRole().equals("user") ||
		 * user.getRole1().getUserRole().equals("Admin"));
		 * 
		 * String message = null; if
		 * (user.getRole1().getUserRole().toUpperCase().equals("USER") ||
		 * user.getRole1().getUserRole().toUpperCase().equals("ADMIN")) {
		 * repo.save(useren); System.out.println(user.getRole1().getUserRole()); message
		 * = "Hello " + user.getUserName() + " Your Registration is Successful!!";
		 * System.out.println(user.getRole1().getUserRole()); } else {
		 * 
		 * message = "Please select valid Role!!"; }
		 */
		/* repo.save(useren); */
		return userobj;

	}

	public List<User> getAllusers() {

		
		  List<User> userlist= new ArrayList<>();
//		  repo.findAll().forEach(users::add); Iterable<User> users =repo.findAll();
//		  users.forEach(userlist::add); return userlist;
		 

		/* List<UserDTO> userlist = new ArrayList(); */

		Iterable<User> user = repo.findAll();
		for (User user1 : user) {
			User user2 = new User();
			user2.setUserId(user1.getUserId());
			user2.setEmail(user1.getEmail());
			user2.setPassword(user1.getPassword());
			user2.setPhoneNumber(user1.getPhoneNumber());
			user2.setUserName(user1.getUserName());

			user2.setRole1(user1.getRole1());

			userlist.add(user2);
		}

		/*
		 * Iterable<User> user =repo.findAll(); user.forEach(userlist::add);
		 */
		return userlist;

	}

	/*
	 * public UserDTO getUser(int username) { UserDTO user1=null; Optional<User>
	 * optuser=repo.findById(username); if(optuser.isPresent()) { User
	 * user=optuser.get(); user1.setEmail(user.getEmail());
	 * user1.setPassword(user.getPassword());
	 * user1.setPhoneNumber(user.getPhoneNumber());
	 * user1.setUserId(user.getUserId()); user1.setUserName(user.getUserName());
	 * 
	 * }
	 * 
	 * return user1;
	 */

	public User getUserByUserName(String username) {

		return repo.findByUserName(username);

	}

	public Iterable<User> deleteUserByUsername(String username) {

		repo.deleteByUserName(username);
		return repo.findAll();
	}

	public User updateUser(User user,String username) {
		User newuser=repo.findByUserName(username);
		newuser.setEmail(user.getEmail());
		newuser.setPassword(user.getPassword());
		newuser.setPhoneNumber(user.getPhoneNumber());
		Optional<Role> role=rolerepo.findById(user.getRole1().getUserRole());
		newuser.setRole1(role.get());
		newuser.setUserId(user.getUserId());
		newuser.setUserName(user.getUserName());
		
		return repo.save(newuser);
	}

	public User LoginUser(User newuser) throws Exception {
		User user = repo.findByUserName(newuser.getUserName());
		String tempusername = newuser.getUserName();
		String temppassword = newuser.getPassword();
		String message;
		User userobj = null;
		if (tempusername != null && temppassword != null) {
			userobj = repo.findByUserNameAndPassword(tempusername, temppassword);
		}
		if (userobj == null) {
			throw new Exception("Bad Credentials");
		}
		/*
		 * if(user!=null) { if(newuser.getPassword().equals(user.getPassword())) {
		 * message="Login is successfull!!"; } else { message="wrong passwod"; }
		 * System.out.println("user is there"); } else {
		 * message="wrong username and passwod";
		 * System.out.println("user is not there"); }
		 */
		return userobj;
	}
	/* Optional<User> optuser=repo.findById(user.getUsername()); */
	/*
	 * User user=new User(); if(optuser.isPresent()) {
	 * 
	 * }
	 */
}
