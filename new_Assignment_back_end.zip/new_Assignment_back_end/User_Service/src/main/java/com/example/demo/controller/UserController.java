package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.dto.UserDTO;
import com.example.demo.dto.UserLogin;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.LoginService;

@RestController
@CrossOrigin
public class UserController {
	
	@Autowired
	UserRepository repo;
	
	@Autowired
	LoginService serv;
	
	/*
	 * @GetMapping("/admin/users") public List<User> getAllUser(){ return
	 * serv.getAllUser(); }
	 */
	/*
	 * @RequestMapping("/login") public String userloginpage() { return "Login.jsp";
	 * }
	 */
	
	@PostMapping(value="/customer")
	@Transactional
	@CrossOrigin
	public User regestration(@RequestBody User user) throws Exception {
		User userentity=new User();
	 
		
		return serv.createUser(user);
		
	}
	
	
	
	@GetMapping("/user/{username}")
	@Transactional
	@CrossOrigin
	public User getUserByUserName(@PathVariable String username) {
		
		
		return serv.getUserByUserName(username);
		
	}
	
	@GetMapping(value="/Alluser")
	@Transactional
	@CrossOrigin
	public List<User> getUset() {
		return serv.getAllusers();
		
	}
	
	
	 @GetMapping(value="/getuser/{username}")
	 @Transactional
	 public User getuser(@PathVariable
	 String username) {
		 
		 serv.getUserByUserName(username);
			/*
			 * Optional<User> optuser=repo.findById(username); User user=new User();
			 * if(optuser.isPresent()) {
			 * 
			 * user.setEmail(optuser.get().getEmail());
			 * user.setPassword(optuser.get().getPassword());
			 * user.setPhoneNumber(optuser.get().getPhoneNumber()); Role role2=new Role();
			 * role2.setUserRole(optuser.get().getRole1().getUserRole());
			 * user.setRole1(role2); }
			 */
		 return serv.getUserByUserName(username);
			/* UserDTO Uer=null; */
			/* return Uer; */
	  
	  }
	 
	 @GetMapping(value="/delete/{username}")
	 @Transactional
	 public Iterable<User> deleteUserByUsername(@PathVariable String username){
		 return serv.deleteUserByUsername(username);
		 
	 }
	 
	 @RequestMapping(method=RequestMethod.PUT, value="/user/{username}")
		public User updateUser(@RequestBody User user,@PathVariable String username) {
			
			return serv.updateUser(user,username);
			
			
		}		 
	 
		
	
		 @PostMapping(value="/login") 
		 public User LoginUser(@RequestBody User logindetails) throws Exception {
			return serv.LoginUser(logindetails);
			 
		 }
		 
	

}
