package com.Ticket.BookingService.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Ticket.BookingService.Entity.Movie;
import com.Ticket.BookingService.Entity.Show;
import com.Ticket.BookingService.Entity.Theatre;


@Repository
public interface ShowRepository extends CrudRepository<Show,Integer> {
	
	/* public Iterable<User> deleteByUserName(String userName); */
	
 public Show findBymovieid(Movie movieid);
 
 public Show findBytheatreid(Theatre theatreid);
	

}
