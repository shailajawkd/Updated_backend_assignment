package com.Ticket.BookingService.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Booking {
	
	@Id
	private int bookingid;
	@OneToOne
	@JoinColumn(name="userid",referencedColumnName="userId")
	private User userid;
	@OneToOne
	@JoinColumn(name="showid")
    private Show showid;
	/*
	 * private String showtime; private String showdate;
	 */
	private int seatsbooked;
	private int amount;
	private String bookingstatus;
	public int getBookingid() {
		return bookingid;
	}
	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}
	public User getUserId() {
		return userid;
	}
	public void setUserId(User userId) {
		this.userid = userId;
	}
	public Show getShowid() {
		return showid;
	}
	public void setShowid(Show showid) {
		this.showid = showid;
	}
	public int getSeatsbooked() {
		return seatsbooked;
	}
	public void setSeatsbooked(int seatsbooked) {
		this.seatsbooked = seatsbooked;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getBookingstatus() {
		return bookingstatus;
	}
	public void setBookingstatus(String bookingstatus) {
		this.bookingstatus = bookingstatus;
	}
	
	

}
