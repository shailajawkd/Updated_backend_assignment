package com.Ticket.BookingService.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Ticket.BookingService.Entity.Booking;



@Repository
public interface BookingRepository extends CrudRepository<Booking,Integer> {

}
