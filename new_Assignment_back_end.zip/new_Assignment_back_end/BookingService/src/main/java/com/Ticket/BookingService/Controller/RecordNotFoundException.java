package com.Ticket.BookingService.Controller;

public class RecordNotFoundException extends RuntimeException {
	
	public RecordNotFoundException(String s) {
		super(s);
	}

}
