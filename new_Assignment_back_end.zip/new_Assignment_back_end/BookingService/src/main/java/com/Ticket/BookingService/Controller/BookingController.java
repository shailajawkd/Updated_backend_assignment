package com.Ticket.BookingService.Controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.Ticket.BookingService.Entity.Movie;
import com.Ticket.BookingService.Entity.MoviesList;
import com.Ticket.BookingService.Entity.Show;
import com.Ticket.BookingService.Service.BookingService;
import com.Ticket.BookingService.model.Report;
import com.Ticket.BookingService.Entity.AddShow;
import com.Ticket.BookingService.Entity.BookTickets;
import com.Ticket.BookingService.Entity.Booking;
import com.Ticket.BookingService.Entity.Bookingdetails;
import com.Ticket.BookingService.Entity.GetShow;

@RestController
@CrossOrigin
public class BookingController {

	@Autowired
	BookingService bserv;

	@Autowired
	private RestTemplate restTemplate;

	/*
	 * @GetMapping("/getallmovies") public MoviesList getMovies() { MoviesList
	 * list=restTemplate.getForObject("http://localhost:8082/AllMovies",MoviesList.
	 * class); return list; }
	 */
	@PostMapping("/addshow")
	@Transactional
	public ResponseEntity<Show> AddShow(@RequestBody AddShow show) {

		return bserv.Addshow(show);

	}
	
	 @PostMapping("/booking")
	 @Transactional
	 public ResponseEntity<Booking> AddBooking(@RequestBody BookTickets bookticket) {
	  
	       return bserv.AddBooking(bookticket);
	  
	 }
	 
	
	  @GetMapping("/allbookings") 
	  @Transactional 
	  @CrossOrigin
	  public List<Bookingdetails> getallbookings()
	 {
		 return bserv.getallbookings();
	  
	  }
	

     @GetMapping("/deletebooking/{bookingid}")	 
	 @Transactional
	 @CrossOrigin
	 public ResponseEntity<List<Bookingdetails>> deleteBooking(@PathVariable int bookingid) {
	  
	  return bserv.deleteBooking(bookingid);
	  
	  }
	
	
	  @GetMapping("/allshows") 
	  @Transactional 
	  public List<GetShow> getallshows(){
	  
	  return bserv.getallshows();
	  
	 
	  }


	 @GetMapping("/deleteshow/{showid}")
	 @Transactional
	 public ResponseEntity<List<GetShow>> deleteshowbyid(@PathVariable int showid) {
		 return bserv.deleteshowbyid(showid);
	  
			/* return bserv.deleteshowbyid(showid); */
	  
	  }
	 @GetMapping("/getshow/{showid}")
	 @Transactional
	 public ResponseEntity<Show> getShowByid(@PathVariable int showid) {
		 return bserv.getShowById(showid);
	 }
	 
	 @GetMapping("/getdisplyshow/{showid}")
	 @Transactional
	 public ResponseEntity<GetShow> getdisplyShowByid(@PathVariable int showid) {
		 return bserv.getdisplayShowById(showid);
	 }
	

	  @PutMapping("/updateshow/{showid}")
	  @Transactional
	  public ResponseEntity<Show> updateshowbyid(@RequestBody GetShow show,@PathVariable int showid) 
	  { 
		 return bserv.updateshowbyid(show,showid);
	  
	  }
	  
	  @GetMapping("/getshowbytheatre/{theatrename}")
	  @Transactional
	  public List<GetShow> getShowByTheatre(@PathVariable String theatrename){
		  
		  return bserv.getShowByTheatre(theatrename);
		  
	  }
	  @GetMapping("/getshowbymovie/{moviename}")
	  @Transactional
	  public List<GetShow> getShowByMovie(@PathVariable String moviename){
		  
		  return bserv.getShowByMovie(moviename);
		  
	  }
	
	  @GetMapping("/getreport/{fromdate}/{enddate}")
	  @Transactional
	  public ResponseEntity<List<Report>> getreport(@PathVariable String fromdate,@PathVariable String enddate) {
		  
		 return bserv.getreport(fromdate, enddate);
		  
		  
	  }

}
