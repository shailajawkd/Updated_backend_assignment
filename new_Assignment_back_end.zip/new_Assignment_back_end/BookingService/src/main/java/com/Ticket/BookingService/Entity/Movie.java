package com.Ticket.BookingService.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Movie {
	
	@Id
	private int movieId;
	private String movieName;
	private String rating;
	private String releaseDate;
	
	/*
	 * @OneToOne(mappedBy="movieid",cascade = CascadeType.ALL) private Show show;
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * public Show getShow() { return show; } public void setShow(Show show) {
	 * this.show = show;
	 * 
	 * }
	 */
	 
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	
	

}
