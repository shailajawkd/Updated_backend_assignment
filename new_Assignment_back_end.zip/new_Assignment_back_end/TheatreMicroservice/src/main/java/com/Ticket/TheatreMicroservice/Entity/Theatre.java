package com.Ticket.TheatreMicroservice.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Theatre {
	
	@Id
	private int theatreId;
	private String theatreName;
	private String location;
	private String seatCapacity;
	public int getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(String seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	
	

}
