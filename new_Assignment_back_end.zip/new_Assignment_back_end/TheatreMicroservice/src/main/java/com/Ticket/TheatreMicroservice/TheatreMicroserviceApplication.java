package com.Ticket.TheatreMicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheatreMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheatreMicroserviceApplication.class, args);
	}

}
